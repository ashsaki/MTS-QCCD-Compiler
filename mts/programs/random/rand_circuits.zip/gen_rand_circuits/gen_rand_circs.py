from qiskit import QuantumCircuit
from qiskit.circuit.random import random_circuit
from qiskit.converters import circuit_to_dag
from qiskit import transpile
import os


idx = 0
for num_qubits in [60, 65, 70, 75]:
    for depth in [10, 15, 20]:
        for k in range(10):
            circ = random_circuit(num_qubits=num_qubits, depth=depth, max_operands=3, measure=False)

            circ_transpiled = transpile(circ, basis_gates=['id', 'sx', 'x', 'rz', 'cx'])
            num_cx = circ_transpiled.count_ops()['cx']
            print(f"idx {idx} num cx {num_cx}")

            name = f"{idx}_rand_qubits_{num_qubits}_depth_{depth}_cx_{num_cx}"

            circ_transpiled.qasm(filename=f"{name}.qasm")

            with open(f"{name}.qasm", "r") as f_rd:
                with open(f"{name}_clean.qasm", "w") as f_wr:
                    for line in f_rd:
                        if line.startswith(("cx", "qreg", "OPENQASM", "include")):
                            f_wr.write(line)
            
            os.remove(f"{name}.qasm")

            idx += 1
